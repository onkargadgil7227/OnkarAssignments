package com.mytest;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.mytest.Task;

@Path("/todo")
public class TodoAppService {
	static ArrayList<Task> allTasks = new ArrayList<Task>();
	
	
	//http://localhost:8080/Test/rest/todo/save/1
	//Pass value in request body
	@PUT 
	@Path("/save/{id}")	
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response saveTask(@PathParam("id") int id, String value) {
		System.out.println("task to save...."+value);	
		
		
		Task task = new Task();
		task.setTaskId(id);
		task.setTaskValue(value);	
		
		allTasks.add(task);
		return Response.status(200).entity("Task saved, taskId "+task.getTaskId()).build();
			
	}
	
	//http://localhost:8080/Test/rest/todo/delete/1
	@PUT 
	@Path("/delete/{id}")	
	@Produces(MediaType.TEXT_PLAIN)
	//@Produces(MediaType.APPLICATION_JSON)
	public Response deleteTask(@PathParam("id") int id) {
		System.out.println("task to delete...."+id);	
		boolean isTaskDeleted=false;
		for(Task currentTask  : allTasks) {
			if(currentTask.getTaskId() == id) {
				allTasks.remove(currentTask);
				isTaskDeleted=true;
				System.out.println("Task deleted, taskId "+id);
				break;
			}
		}
		if(!isTaskDeleted){
			return Response.status(400).entity("Task not Found "+id).build();
			
		}
		return Response.status(200).entity("Task deleted, taskId "+id).build();	
	}
	
	//http://localhost:8080/Test/rest/todo/update/1
	// Pass value to update in the request body
	@PUT 
	@Path("/update/{id}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response updateTask(@PathParam("id") int id, String value) {
		System.out.println("task to Update...."+id);	
		boolean isTaskUpdated=false;
		for(Task currentTask  : allTasks) {
			if(currentTask.getTaskId() == id) {
				currentTask.setTaskValue(value);
				System.out.println("Task updated, taskId "+id);
				isTaskUpdated=true;
				break;
			}
		}
		if(!isTaskUpdated){
			return Response.status(400).entity("Task not Found "+id).build();
			
		}
		return Response.status(200).entity("Task updated, taskId "+id).build();	
			
	}
	
	//http://localhost:8080/Test/rest/todo/getAllTasks
	@GET
	@Path("/getAllTasks")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Task> getAllTasks() {
		
		System.out.println("Fetching...");
		
		return allTasks;
	}
	
	//http://localhost:8080/Test/rest/todo/getAllTasks
		@GET
		@Path("/clearAllTasks")
		public ArrayList<Task> clearAllTasks() {
			
			System.out.println("Clearing...");
			allTasks.clear();			
			return allTasks;
		}

	

}
