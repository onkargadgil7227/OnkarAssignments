document.querySelector('form').addEventListener('submit', handleSubmitForm);




function handleSubmitForm(e){
	e.preventDefault();
	let input = document.querySelector('input');
	if(input.value !='')
		addTodo(input.value);
	input.value='';
		
}
function handleClickDeleteOrCheck(e){
	if(e.target.name == 'checkButton')
		checkTodo(e);
	
	if(e.target.name == 'deleteButton')
		deleteTodo(e);
}

function handleClearAll(e){
	document.querySelector('ul').innerHTML = '';
	let url = '/Test/rest/todo/clearAllTasks';
	$.ajax({
	    url: url,
	    type: 'GET',
	    success: function(response) {
	    	console.log(response);
	    	alert(response);
	    }
	});
}

function handleShowAll(e){
	let url = '/Test/rest/todo/getAllTasks';
	$.ajax({
	    url: url,
	    type: 'GET',
	    success: function(response) {
	    	console.log(response);
	    	alert(JSON.stringify(response));
	    }
	});
}


function addTodo(todo){
	let ul = document.querySelector('ul');
	let li = document.createElement('li');
	let todoId = Math.floor(Math.random()*100);
	
	li.innerHTML = `
	<span class="todo-item">${todo}</span>
	<button name="checkButton"><i class="fas fa-check-square"></i></button>
	<button name="deleteButton"><i class="fas fa-trash"</i></button>
	`;
	li.id=todoId;
	li.classList.add('todo-list-item');
	ul.appendChild(li);
	document.querySelector('ul').addEventListener('click', handleClickDeleteOrCheck);
	document.getElementById('clearAll').addEventListener('click', handleClearAll);
	document.getElementById('showAll').addEventListener('click', handleShowAll);
	let url = '/Test/rest/todo/save/'+ todoId;
	
	$.ajax({
	    url: url,
	    type: 'PUT',
		contentType: "text/plain",
	    dataType: "text",
	    data:todo,
	    success: function(response) {
	    	console.log(response);
	    	alert(response);
	    }
	});
}

function checkTodo(e)
{
let item = e.target.parentNode;
if(item.style.textDecoration == 'line-through')
	item.style.textDecoration = 'none';
else
	item.style.textDecoration = 'line-through';
}

function deleteTodo(e){
	let item = e.target.parentNode;
	let todoIdToRemove= item.id;
	
	item.addEventListener('transitioned', function(){
		item.remove();
	})
	
	item.classList.add('todo-list-item-fall');
	
	item.remove();
	
	
	let url = '/Test/rest/todo/delete/'+ todoIdToRemove;
	$.ajax({
	    url: url,
	    type: 'PUT',
		contentType: "text/plain",
	    success: function(response) {
	    	console.log(response);
	    	alert(response);
	    }
	});
}